# CloudSim
Project to collect CloudSim configurations and corresponding performance values

- Compile
javac -cp ~/tmp/CloudSimVCL/CloudSim_Project/bin/:~/tmp/CloudSimVCL/CloudSim_Project/modules/cloudsim-examples/src/main/java org/cloudbus/cloudsim/examples/power/random/ConfigRunner

- Execute
java -Dfile.encoding=UTF-8 -classpath "/Users/viveknair/tmp/CloudSimVCL/CloudSim_Project/bin/":"/Users/viveknair/tmp/CloudSimVCL/dependency/commons-math3-3.6.1.jar":"/Users/viveknair/tmp/CloudSimVCL/dependency/easymock-3.0 2.jar":"/Users/viveknair/tmp/CloudSimVCL/dependency/junit.jar":"/Users/viveknair/tmp/CloudSimVCL/dependency/org.hamcrest.core_1.3.0.v201303031735.jar":"/Users/viveknair/tmp/CloudSimVCL/dependency/opencsv-3.3.jar" org/cloudbus/cloudsim/examples/power/random/ConfigRunner iqr mc 1.39367467979 160 200 10000 1000000 1000000 200 0 0 0 160 0 0 0 1
